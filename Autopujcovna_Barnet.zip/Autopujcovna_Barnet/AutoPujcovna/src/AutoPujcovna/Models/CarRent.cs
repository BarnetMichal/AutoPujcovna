﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoPujcovna.Models
{
    public class CarRent
    {
        public Car car { get; set; }
        public User user { get; set; }
    }
}
