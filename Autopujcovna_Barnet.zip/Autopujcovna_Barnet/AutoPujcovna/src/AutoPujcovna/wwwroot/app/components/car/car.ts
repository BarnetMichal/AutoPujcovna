export interface Car {

    ID: number,
    LicencePlate: string,
    Name: string,

}