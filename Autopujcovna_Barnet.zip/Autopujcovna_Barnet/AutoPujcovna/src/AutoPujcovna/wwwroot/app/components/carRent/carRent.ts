
import { Car } from '../car/car';
import { User } from '../user/user';

export interface CarRent {

    User: User,
    Car: Car
    
}