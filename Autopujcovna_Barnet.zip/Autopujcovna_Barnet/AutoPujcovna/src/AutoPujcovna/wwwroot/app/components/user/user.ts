export interface User {

    ID: number,
    FirstName: string,
    LastName: string,

}