
export class Column {
  name: string;
  descr: string;
  constructor(name, descr) {
    this.name = name;
    this.descr = descr;
  }
}
